<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User- Login and Register</title>
    <link rel="stylesheet" href="style3.css">
    <style>
        body {
            background-image: "niet3.jpg";
            background-size: cover;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: left;
            height: 10vh;
            padding: 10px;
            background-color: yellow; /* Optional background color for header */
        }
        .sign-in-up {
            display: flex;
            gap: 20px;
        }
    </style>
</head>
<body>
<header>
<h2>NIET SCSIT</h2>
<div class="sign-in-up">
<a href="../admin/admin_login.php" type="button" style=" width:20vh; height:4vh;margin-left:750px;"><b><i>Admin Login</i></b></button>
<a href="user_login.php" type="button" style=" width:15vh; height:4vh;margin-left:30px;"><b><i>User Login</i></b></button> 
<a href= "register.php" style="width:20vh; height:4vh;margin-left:30px;"><b><i>Register User</i></b></button>  
</div>
<!-- <div>
    <img src="niet3.jpg">
</div> -->
</header>
</body>
</html>