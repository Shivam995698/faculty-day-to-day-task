 <?php

$connection = mysqli_connect("localhost", "root", ""); //
$db = mysqli_select_db( $connection,"faculty_task_management");
?> 
