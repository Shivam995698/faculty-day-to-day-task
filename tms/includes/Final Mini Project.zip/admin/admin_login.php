


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FTMS |ADMIN Login page</title>
    <script src="../includes/jquery_latest.js"></script>
    <link rel='stylesheet'type='text/css' href="../bootstrap/css/bootstrap.min.css">
    <script src="../bootstrap/js/bootstrap.min.js"></script> 
    <link rel="styleshhet" type="text/css" href="../css/style.css">
   
    <style>
body{
    background-color:rebeccapurple;
    
}
#login_home_page{
    background-color:maroon;

}
</style>   
</head>
<body>
    <div class="row" style="background-color:'#f5f5f5'">
        <div class="col-md-3 m-auto" id="login_home_page" >
            <center><h3 style="background-color:#5A8F7B; padding:5px; width:15vw;">Admin Login</h3></center>
            <form action="admin_dashboard.php" method='post'>
                <div class='form-group'>
                    <input type='email' name="AdminEmail" class="form-control"  placeholder="Enter your email id" required><br/>
                </div>
                <div class='form-group'>
                    <input type='password' name="AdminPassword" class="form-control"  placeholder="Enter your password" required><br/>
                </div>
                <div class="form-group">
                 <center>   <input type='submit' name="adminLogin" value='Login' class='btn btn-warning'></center>
                </div>
</form>
<center><a href="../includes/index.html" class="btn btn-danger">Go to the home page</a></center>
    </div>
</body>
</div>
</html>