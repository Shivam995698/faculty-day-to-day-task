-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2024 at 05:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faculty_task_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AdminName` varchar(200) NOT NULL,
  `AdminId` varchar(100) NOT NULL,
  `AdminContact` bigint(20) NOT NULL,
  `AdminEmail` varchar(50) NOT NULL,
  `AdminPassword` varchar(20) NOT NULL,
  `is_verified` int(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AdminName`, `AdminId`, `AdminContact`, `AdminEmail`, `AdminPassword`, `is_verified`) VALUES
('Admin', '2k0f6345', 9705484759, 'admin@gmail.com', '123@sd', 1);

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `Faculty_Name` varchar(100) NOT NULL,
  `Faculty_Id` varchar(20) NOT NULL,
  `Contact` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `verification_code` text NOT NULL,
  `is_verified` int(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`Faculty_Name`, `Faculty_Id`, `Contact`, `Email`, `Password`, `verification_code`, `is_verified`) VALUES
('Amit', '15df84ss', '9508123692', 'akm@gmail.com', '1234', '', 0),
('shivam', '154fg5332', '7522072697', 'shivam@gmail.com', '456', '', 0),
('Faizan', '125ko548', '9525251158', 'akdm2024@gmail.com', '456', '4b0984b2296923c92fc062db7dbf95e8', 0),
('aakash', '12510656', '9508123692', 'akm95081@gmail.com', '1234', 'bf5220b1ab6af82ca682b451616674b6', 1);

-- --------------------------------------------------------

--
-- Table structure for table `regular_work`
--

CREATE TABLE `regular_work` (
  `task_id` int(11) NOT NULL,
  `Faculty_Name` varchar(50) NOT NULL,
  `Faculty_Id` varchar(20) NOT NULL,
  `Day` varchar(20) NOT NULL,
  `Start_time` varchar(20) NOT NULL,
  `End_time` varchar(20) NOT NULL,
  `Subject` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `regular_work`
--

INSERT INTO `regular_work` (`task_id`, `Faculty_Name`, `Faculty_Id`, `Day`, `Start_time`, `End_time`, `Subject`, `class`) VALUES
(1, 'Amit', '15df84ss', 'Tuesday', '11:10', '12:00', 'daa', 'cse iv a'),
(2, 'aakash', '12510656', 'Monday', '09:50', '10:40', 'OPERATING SYSTEM', 'CSE IV B'),
(3, 'aakash', '12510656', 'Monday', '09:50', '10:40', 'OPERATING SYSTEM', 'CSE IV B'),
(4, 'aakash', '12510656', 'Tuesday', '02:55', '03:55', 'os lab', 'cse iii c');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `Faculty_Id` varchar(20) NOT NULL,
  `Faculty_Name` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `task_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`Faculty_Id`, `Faculty_Name`, `description`, `start_date`, `end_date`, `status`, `image`, `task_id`) VALUES
('154fg5332', 'shivam', 'publish attendance sheet.', '2024-04-20', '2024-04-24', 'Not Started', 'nad', 2),
('akm@gmail.com', 'saas', 'update', '2024-04-26', '2024-04-27', 'Not Started', 'nad', 3),
('akm@gmail.com', 'saas', 'update', '2024-04-26', '2024-04-26', 'Not Started', 'nad', 4),
('15df84ss', 'Amit', 'update attendance', '2024-04-27', '2024-04-27', 'Not Started', 'abcd', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `regular_work`
--
ALTER TABLE `regular_work`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `regular_work`
--
ALTER TABLE `regular_work`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `task_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
